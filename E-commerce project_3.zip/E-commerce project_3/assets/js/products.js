import { animateElement, pageTransition } from './utils/animations.js';
import { formatPrice } from './utils/cart.js';

document.addEventListener('DOMContentLoaded', () => {
  pageTransition();

  const productsGrid = document.querySelector('.products-grid');
  const filterSelects = document.querySelectorAll('.filter-select');
  const paginationButtons = document.querySelectorAll('.page-btn');

  // Sample products data
  const products = [
    {
      id: 1,
      name: "Facial Cleanser",
      price: 29.00,
      category: "Skincare",
      rating: 4.8,
      reviews: 124,
      image: "./assets/images/product-01.jpg"
    },
    // Add more products...
  ];

  function renderProducts(products) {
    productsGrid.innerHTML = products.map((product, index) => `
      <div class="product-card" style="animation-delay: ${index * 0.1}s">
        <div class="product-image">
          <img src="${product.image}" alt="${product.name}">
          <div class="product-actions">
            <button class="action-btn" onclick="addToWishlist(${product.id})">
              <ion-icon name="heart-outline"></ion-icon>
            </button>
            <button class="action-btn" onclick="quickView(${product.id})">
              <ion-icon name="eye-outline"></ion-icon>
            </button>
          </div>
        </div>
        <div class="product-content">
          <p class="product-category">${product.category}</p>
          <h3>
            <a href="product.html?id=${product.id}" class="product-title">${product.name}</a>
          </h3>
          <p class="product-price">${formatPrice(product.price)}</p>
          <div class="product-rating">
            <div class="rating-stars">
              ${Array(5).fill('').map((_, i) => `
                <ion-icon name="${i < Math.floor(product.rating) ? 'star' : 'star-outline'}"></ion-icon>
              `).join('')}
            </div>
            <span>(${product.reviews})</span>
          </div>
          <button class="btn btn-primary" onclick="addToCart(${product.id})">Add to Cart</button>
        </div>
      </div>
    `).join('');

    // Add animations to new elements
    document.querySelectorAll('.product-card').forEach(card => {
      card.addEventListener('mouseenter', () => {
        animateElement(card, 'scale-in');
      });
    });
  }

  // Filter handling
  filterSelects.forEach(select => {
    select.addEventListener('change', () => {
      // Add filter logic here
      animateElement(select, 'bounce');
    });
  });

  // Pagination handling
  paginationButtons.forEach(button => {
    button.addEventListener('click', () => {
      paginationButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      animateElement(button, 'bounce');
      // Add pagination logic here
    });
  });

  // Initialize
  renderProducts(products);
});