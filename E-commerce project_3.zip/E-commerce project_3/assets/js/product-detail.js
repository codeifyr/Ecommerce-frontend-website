import { animateElement, pageTransition } from './utils/animations.js';
import { formatPrice } from './utils/cart.js';

document.addEventListener('DOMContentLoaded', () => {
  pageTransition();

  const mainImage = document.querySelector('.main-image img');
  const thumbnails = document.querySelectorAll('.thumbnail');
  const quantityInput = document.querySelector('.quantity-input');
  const quantityBtns = document.querySelectorAll('.quantity-btn');
  const addToCartBtn = document.querySelector('.add-to-cart');
  const buyNowBtn = document.querySelector('.buy-now');

  // Sample product data
  const product = {
    id: 1,
    name: "Facial Cleanser",
    price: 29.00,
    description: "A gentle, effective cleanser that removes impurities while maintaining skin's natural moisture balance.",
    category: "Skincare",
    rating: 4.8,
    reviews: 124,
    sku: "SKU-001",
    stock: 50,
    images: [
      "./assets/images/product-01.jpg",
      "./assets/images/product-02.jpg",
      "./assets/images/product-03.jpg"
    ]
  };

  function updateMainImage(src) {
    mainImage.style.opacity = '0';
    setTimeout(() => {
      mainImage.src = src;
      mainImage.style.opacity = '1';
    }, 300);
  }

  thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener('click', () => {
      thumbnails.forEach(t => t.classList.remove('active'));
      thumbnail.classList.add('active');
      updateMainImage(thumbnail.querySelector('img').src);
      animateElement(thumbnail, 'bounce');
    });
  });

  quantityBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const value = parseInt(quantityInput.value);
      if (btn.classList.contains('minus')) {
        if (value > 1) quantityInput.value = value - 1;
      } else {
        if (value < product.stock) quantityInput.value = value + 1;
      }
      animateElement(btn, 'bounce');
    });
  });

  addToCartBtn.addEventListener('click', () => {
    animateElement(addToCartBtn, 'bounce');
    // Add to cart logic here
  });

  buyNowBtn.addEventListener('click', () => {
    animateElement(buyNowBtn, 'bounce');
    // Buy now logic here
  });
});