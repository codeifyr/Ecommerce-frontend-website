import { animateElement, pageTransition } from './utils/animations.js';
import { calculateTotals, formatPrice, updateCartCount } from './utils/cart.js';

document.addEventListener('DOMContentLoaded', () => {
  pageTransition();
  
  const cartItems = document.querySelector('.cart-items');
  const subtotalElement = document.querySelector('.subtotal');
  const totalElement = document.querySelector('.total-amount');
  const checkoutBtn = document.querySelector('.checkout-btn');

  let cart = [
    {
      id: 1,
      name: "Facial Cleanser",
      price: 29.00,
      quantity: 1,
      image: "./assets/images/product-01.jpg"
    }
  ];

  function updateCart() {
    cartItems.innerHTML = cart.map((item, index) => `
      <div class="cart-item" style="animation-delay: ${index * 0.1}s">
        <img src="${item.image}" alt="${item.name}">
        <div class="item-details">
          <h3 class="item-title">${item.name}</h3>
          <p class="item-price">${formatPrice(item.price)}</p>
          <div class="quantity-controls">
            <button class="quantity-btn minus" onclick="updateQuantity(${item.id}, -1)">-</button>
            <span>${item.quantity}</span>
            <button class="quantity-btn plus" onclick="updateQuantity(${item.id}, 1)">+</button>
          </div>
        </div>
        <button class="remove-btn" onclick="removeItem(${item.id})">
          <ion-icon name="trash-outline"></ion-icon>
        </button>
      </div>
    `).join('');

    const { subtotal, total } = calculateTotals(cart);
    subtotalElement.textContent = formatPrice(subtotal);
    totalElement.textContent = formatPrice(total);
    
    updateCartCount(cart.length);
  }

  window.updateQuantity = (id, change) => {
    const item = cart.find(item => item.id === id);
    if (item) {
      item.quantity = Math.max(1, item.quantity + change);
      const quantityBtn = event.target;
      animateElement(quantityBtn, 'bounce');
      updateCart();
    }
  };

  window.removeItem = (id) => {
    const itemElement = document.querySelector(`[data-id="${id}"]`);
    itemElement.style.animation = 'slideIn 0.5s ease-out reverse';
    
    setTimeout(() => {
      cart = cart.filter(item => item.id !== id);
      updateCart();
    }, 500);
  };

  checkoutBtn.addEventListener('click', () => {
    animateElement(checkoutBtn, 'bounce');
    setTimeout(() => {
      window.location.href = 'checkout.html';
    }, 300);
  });

  updateCart();
});