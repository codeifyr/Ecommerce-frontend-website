export const animateElement = (element, className) => {
  element.classList.add(className);
  element.addEventListener('animationend', () => {
    element.classList.remove(className);
  }, { once: true });
};

export const pageTransition = () => {
  document.body.classList.add('page-transition');
  window.addEventListener('load', () => {
    document.body.classList.add('loaded');
  });
};

export const addButtonAnimation = (button) => {
  button.addEventListener('click', () => {
    animateElement(button, 'bounce');
  });
};