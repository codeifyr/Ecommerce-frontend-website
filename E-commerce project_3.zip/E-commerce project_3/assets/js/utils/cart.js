export const calculateTotals = (cart) => {
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = 5.00;
  const total = subtotal + shipping;
  
  return { subtotal, shipping, total };
};

export const formatPrice = (price) => {
  return `$${price.toFixed(2)}`;
};

export const updateCartCount = (count) => {
  const cartBadge = document.querySelector('.header-action-btn .btn-badge');
  if (cartBadge) {
    cartBadge.textContent = count;
    animateElement(cartBadge, 'bounce');
  }
};