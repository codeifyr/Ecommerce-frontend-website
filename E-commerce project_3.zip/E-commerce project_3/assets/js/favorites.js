import { animateElement, pageTransition } from './utils/animations.js';
import { formatPrice } from './utils/cart.js';

document.addEventListener('DOMContentLoaded', () => {
  pageTransition();
  
  const favoritesGrid = document.querySelector('.favorites-grid');
  const emptyFavorites = document.querySelector('.empty-favorites');

  let favorites = [
    {
      id: 1,
      name: "Facial Cleanser",
      price: 29.00,
      image: "./assets/images/product-01.jpg"
    }
  ];

  function updateFavorites() {
    if (favorites.length === 0) {
      favoritesGrid.style.display = 'none';
      emptyFavorites.classList.remove('hidden');
      animateElement(emptyFavorites, 'fadeIn');
    } else {
      favoritesGrid.style.display = 'grid';
      emptyFavorites.classList.add('hidden');

      favoritesGrid.innerHTML = favorites.map((item, index) => `
        <div class="favorite-item" data-id="${item.id}" style="animation-delay: ${index * 0.1}s">
          <img src="${item.image}" alt="${item.name}">
          <div class="favorite-content">
            <h3 class="favorite-title">${item.name}</h3>
            <p class="favorite-price">${formatPrice(item.price)}</p>
            <div class="favorite-actions">
              <button class="btn btn-primary" onclick="addToCart(${item.id})">Add to Cart</button>
              <button class="btn btn-secondary" onclick="removeFromFavorites(${item.id})">Remove</button>
            </div>
          </div>
        </div>
      `).join('');

      // Add button animations
      document.querySelectorAll('.favorite-actions button').forEach(button => {
        button.addEventListener('click', () => animateElement(button, 'bounce'));
      });
    }
  }

  window.addToCart = (id) => {
    const item = favorites.find(item => item.id === id);
    if (item) {
      animateElement(event.target, 'bounce');
      // Add to cart logic here
      console.log(`Added item ${id} to cart`);
    }
  };

  window.removeFromFavorites = (id) => {
    const itemElement = document.querySelector(`[data-id="${id}"]`);
    itemElement.style.animation = 'scaleIn 0.5s ease-out reverse';
    
    setTimeout(() => {
      favorites = favorites.filter(item => item.id !== id);
      updateFavorites();
    }, 500);
  };

  updateFavorites();
});